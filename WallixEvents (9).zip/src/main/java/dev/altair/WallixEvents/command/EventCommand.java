package dev.altair.WallixEvents.command;

import dev.altair.WallixEvents.WallixEvents;
import dev.altair.WallixEvents.event.EventManager;
import dev.altair.WallixEvents.gui.MenuGUI;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Обработчик команды /event.
 */
public class EventCommand implements CommandExecutor {

    private final WallixEvents plugin;
    private final EventManager eventManager;

    public EventCommand(WallixEvents plugin) {
        this.plugin = plugin;
        this.eventManager = plugin.getEventManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("wallixevents.admin")) {
            sender.sendMessage(ChatColor.RED + "У вас нет прав для выполнения этой команды.");
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "start" -> {
                if (args.length < 2) {
                    sender.sendMessage(ChatColor.RED + "Укажите название ивента.");
                    return true;
                }
                String eventName = args[1];
                if (eventManager.startEvent(eventName, sender)) {
                    sender.sendMessage(ChatColor.GREEN + "Ивент " + eventName + " запущен.");
                } else {
                    sender.sendMessage(ChatColor.RED + "Не удалось запустить ивент " + eventName + ".");
                }
            }
            case "stop" -> {
                if (eventManager.stopCurrentEvent()) {
                    sender.sendMessage(ChatColor.YELLOW + "Текущий ивент остановлен.");
                } else {
                    sender.sendMessage(ChatColor.RED + "Нет запущенного ивента.");
                }
            }
            case "delay" -> {
                long delay = eventManager.getRemainingDelay();
                sender.sendMessage(ChatColor.AQUA + "Оставшееся время до авто-ивента: " + delay + " сек.");
            }
            case "reload" -> {
                plugin.reloadConfigs();
                sender.sendMessage(ChatColor.GREEN + "Конфиги перезагружены.");
            }
            case "region" -> {
                if (args.length < 3) {
                    sender.sendMessage(ChatColor.RED + "Использование: /event region <set/remove> <name>");
                    return true;
                }
                // Реализация управления регионами (запись в config.yml)
                // Для простоты сохраняем координаты текущего положения игрока.
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(ChatColor.RED + "Эту команду может выполнить только игрок.");
                    return true;
                }
                String action = args[1];
                String regionName = args[2];
                if (action.equalsIgnoreCase("set")) {
                    plugin.getConfigManager().getConfig().set("regions." + regionName + ".world", player.getWorld().getName());
                    plugin.getConfigManager().getConfig().set("regions." + regionName + ".x1", player.getLocation().getBlockX());
                    plugin.getConfigManager().getConfig().set("regions." + regionName + ".z1", player.getLocation().getBlockZ());
                    plugin.getConfigManager().getConfig().set("regions." + regionName + ".x2", player.getLocation().getBlockX() + 10);
                    plugin.getConfigManager().getConfig().set("regions." + regionName + ".z2", player.getLocation().getBlockZ() + 10);
                    plugin.saveConfig();
                    sender.sendMessage(ChatColor.GREEN + "Регион " + regionName + " установлен.");
                } else if (action.equalsIgnoreCase("remove")) {
                    plugin.getConfigManager().getConfig().set("regions." + regionName, null);
                    plugin.saveConfig();
                    sender.sendMessage(ChatColor.YELLOW + "Регион " + regionName + " удалён.");
                } else {
                    sender.sendMessage(ChatColor.RED + "Неизвестное действие: " + action);
                }
            }
            case "menu" -> {
                if (sender instanceof Player player) {
                    new MenuGUI(plugin).open(player);
                } else {
                    sender.sendMessage(ChatColor.RED + "Эту команду может выполнить только игрок.");
                }
            }
            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "=== WallixEvents команды ===");
        sender.sendMessage(ChatColor.YELLOW + "/event start <name> " + ChatColor.WHITE + "- запустить ивент");
        sender.sendMessage(ChatColor.YELLOW + "/event stop " + ChatColor.WHITE + "- остановить текущий ивент");
        sender.sendMessage(ChatColor.YELLOW + "/event delay " + ChatColor.WHITE + "- показать таймер авто-ивента");
        sender.sendMessage(ChatColor.YELLOW + "/event reload " + ChatColor.WHITE + "- перезагрузить конфиги");
        sender.sendMessage(ChatColor.YELLOW + "/event region <set/remove> <name> " + ChatColor.WHITE + "- управление регионами");
        sender.sendMessage(ChatColor.YELLOW + "/event menu " + ChatColor.WHITE + "- открыть GUI меню лута");
    }
}