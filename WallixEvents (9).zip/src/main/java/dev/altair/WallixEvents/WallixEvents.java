package dev.altair.WallixEvents;

import dev.altair.WallixEvents.command.EventCommand;
import dev.altair.WallixEvents.config.ConfigManager;
import dev.altair.WallixEvents.event.EventManager;
import dev.altair.WallixEvents.hologram.HologramManager;
import dev.altair.WallixEvents.placeholder.WallixEventsExpansion;
import dev.altair.WallixEvents.schematic.SchematicManager;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Главный класс плагина WallixEvents.
 */
public final class WallixEvents extends JavaPlugin {

    private static WallixEvents instance;
    private ConfigManager configManager;
    private EventManager eventManager;
    private HologramManager hologramManager;
    private SchematicManager schematicManager;

    @Override
    public void onEnable() {
        instance = this;
        // Загрузка конфигов
        this.saveDefaultConfig();
        this.reloadConfigs();

        // Инициализация менеджеров
        this.hologramManager = new HologramManager(this);
        this.schematicManager = new SchematicManager(this);
        this.eventManager = new EventManager(this);
        // Регистрация команд
        this.getCommand("event").setExecutor(new EventCommand(this));

        // Регистрация PlaceholderAPI, если установлен
        if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new WallixEventsExpansion(this).register();
        }

        // Логирование
        getLogger().info("WallixEvents включён, версия " + getDescription().getVersion());
    }

    @Override
    public void onDisable() {
        // Остановить текущий ивент, если он запущен
        if (eventManager.isEventRunning()) {
            eventManager.stopCurrentEvent();
        }
        getLogger().info("WallixEvents выключен.");
    }

    public void reloadConfigs() {
        this.configManager = new ConfigManager(this);
        this.configManager.loadAll();
    }

    public static WallixEvents getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public EventManager getEventManager() {
        return eventManager;
    }

    public HologramManager getHologramManager() {
        return hologramManager;
    }

    public SchematicManager getSchematicManager() {
        return schematicManager;
    }
}