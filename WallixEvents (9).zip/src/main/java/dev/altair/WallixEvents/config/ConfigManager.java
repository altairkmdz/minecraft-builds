package dev.altair.WallixEvents.config;

import dev.altair.WallixEvents.WallixEvents;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;

/**
 * Менеджер конфигурационных файлов.
 */
public class ConfigManager {

    private final WallixEvents plugin;
    private YamlConfiguration config;
    private YamlConfiguration events;
    private YamlConfiguration messages;
    private YamlConfiguration menu;
    private YamlConfiguration hologram;

    public ConfigManager(WallixEvents plugin) {
        this.plugin = plugin;
    }

    public void loadAll() {
        this.config = load("config.yml");
        this.events = load("events.yml");
        this.messages = load("messages.yml");
        this.menu = load("menu.yml");
        this.hologram = load("hologram.yml");
    }

    private YamlConfiguration load(String fileName) {
        File file = new File(plugin.getDataFolder(), fileName);
        if (!file.exists()) {
            plugin.saveResource(fileName, false);
        }
        return YamlConfiguration.loadConfiguration(file);
    }

    public void reloadAll() {
        loadAll();
    }

    public YamlConfiguration getConfig() {
        return config;
    }

    public YamlConfiguration getEvents() {
        return events;
    }

    public YamlConfiguration getMessages() {
        return messages;
    }

    public YamlConfiguration getMenu() {
        return menu;
    }

    public YamlConfiguration getHologram() {
        return hologram;
    }

    public void saveEvents() {
        save(events, "events.yml");
    }

    private void save(YamlConfiguration yaml, String fileName) {
        try {
            yaml.save(new File(plugin.getDataFolder(), fileName));
        } catch (IOException e) {
            plugin.getLogger().severe("Не удалось сохранить " + fileName + ": " + e.getMessage());
        }
    }
}